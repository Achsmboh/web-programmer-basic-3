Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 7 :
- Testing
    > Uji coba aplikasi
    > sisi end user
    > menyamar (layaknya end user)
    > attack (hacker)
        - sisi upload (access deneid)
        - curl / post data (access denied - token/authorization)

web develpment
- code
- mode debugging
    > uji coba (sisi programer)
    > aplikasi udah layak
    > atasan/ client/ dll > aplikasinya bisa digunakan?
    Jawab : sudah bisa
process production :
> Development > production

> QA quality asurance
---

- JMeter
- Katalon
- SonarQube

---
form upload
> extension (jpg/png) > tidak boleh allow yang lain
> token, authorization
