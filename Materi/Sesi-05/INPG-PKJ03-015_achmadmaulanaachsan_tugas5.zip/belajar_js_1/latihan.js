var hello = "Saya mulai belajar javascript - dibuat dengan external js";
document.write(hello);
console.log(hello);
