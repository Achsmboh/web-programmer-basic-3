Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 5 :
- Belajar tentang Javascript
- Cara penulisan Javascript
- Penggunaan Variabel di Javascript
- Belajar tipe data
    - string
    - number
    - array
    - object
- Operator Aritmatika
- Function Javascript
- Mengenal event Javascript
- Belajar Kondisional Javascript
- Belajar Perulangan
