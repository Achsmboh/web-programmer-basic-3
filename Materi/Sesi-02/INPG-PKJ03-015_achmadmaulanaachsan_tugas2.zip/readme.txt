Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 2 :
- HTML (Hypertext Markup Language)
- Costum Style (bold, italic, underline, font size, background, font color dll)
- Belajar tag image
- Belajar href
- Belajar Heading
- Belajar Membuat List (ol dan ul)
- Belajar Membuat List Bersarang
- Belajar Penggunaan div
- Belajar Membuat Form
- Belajar Membuat Form Biodata
