Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 4 :
- Algoritma adalah serangkaian urutan langkah-langkah yang tepat, logis, terperinci, dan terbatas untuk menyelesaikan suatu masalah yang disusun secara sistematis.

- Kriteria Algoritma
    - Ada input dan output
    - Efektifitas dan efisien
    - Terstruktur

- FLOWCHART
    Flowchart adalah bagan-bagan yang mempunyai arus menggambarkan langkah-langkah penyelesaian suatu masalah

- PSEUDOCODE
    Psedudocode adalah konvensi terstruktur atau cara menyajikan penjelasan algoritma dengan bahasa yang deskriptif seperti kita menulis kalimat biasa sehingga mudah kita baca. Umumnya digunakan bahasa Inggris atau bahasa perantara yang mirip bahasa pemrograman.