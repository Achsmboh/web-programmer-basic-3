Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 6 :
- Belajar tentang DOM (Document Object Model)
- Membuat, mengisi dan menambahkan element melalui DOM
- Menghapus element menggunakan DOM
- Latihan membuat aplikasi ubah warna
- Belajar mengenai RegExp
    - penulisan RegExp menggunakan literal (/.../)
    - penulisan RegExp menggunakan object constructor (new RegExp)
- Belajar Method test pada RegExp
- Belajar Method exec pada RegExp
- Pola RegExp sebagai String
- Pola Character Set
    - dengan kurung [] maka hanya karakter yang ada di dalam tanda kurung ini saja yang akan memenuhi syarat.

