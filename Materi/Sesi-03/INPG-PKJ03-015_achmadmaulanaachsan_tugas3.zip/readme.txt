Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 3 :
- Belajar mengubah warna background
- Belajar Margin dan Padding
- Belajar link href
- Belajar Font Css
- Belajar Position Css
- Belajar Border Css
- Belajar Cara membuat List
- Belajar Git
- Belajar Git Hub
- Belajar environment dari Git
