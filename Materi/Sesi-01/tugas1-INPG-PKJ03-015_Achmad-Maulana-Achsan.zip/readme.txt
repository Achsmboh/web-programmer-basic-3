Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

Kesimpulan Penjelasan Sesi 1 :
- Installasi VS Code
- Penyamaan persepsi struktur Folder
- Installasi extension/plugin vscode
    - auto close tag (done)
    - html css suport (done)
    - intellense for css (done)
    - prettier (done)
    - live server (done)
- Belajar html
